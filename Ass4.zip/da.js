console.log(text._____());
substring
slice
replace
replaceall

var fruits = ["Banana", "Orange", "Lemon", "Apple", "Mango"];
var citrus = fruits.slice(1, 3);
console.log(citrus);

var str = "Hello world!";
var res = str.substring(1, 4);
console.log(res);

var str = "The rain in SPAIN stays mainly in the plain";
var res = str.match(/ain/g);
console.log(res);


var str = "Hello World!";
var res = str.valueOf();
console.log(res);

var fruits = ["Banana", "Orange", "Apple", "Mango"];
fruits[0] = "Kiwi";

var myGirls = ["Cecilie", "Lone"];
var myBoys = ["Emil", "Tobias", "Linus"];
var myChildren = myGirls.concat(myBoys);
console.log(yChildren);