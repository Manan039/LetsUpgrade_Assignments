let age = prompt("Whats your age");
console.log(age)
let h=confirm("Are you above 21 years ?")
console.log(h)
