console.log("functions");


function hello(){
    console.log("hello from function");
}
hello();


let great =function(){
    console.log("I am a function assigned to variable");

}
great();

// pass parameters

let welcome= function(name){
    console.log(`Hello ${name}`)

}
welcome('Manan');
