let person ={
    name:'Professor',
    skills:['Planning','mind games'],
    teamcount:8,
    canfly:false,
};
console.log(person['skills'])

for(key in person){
    console.log(person['key']);
}