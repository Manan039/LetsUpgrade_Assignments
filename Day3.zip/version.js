let ver = prompt("Enter OS name and version");
let first=ver.split(' ')[0];
let second=ver.split(' ')[1];
console.log(`The OS name is ${first} and version is ${second}`)


