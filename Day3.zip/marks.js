let mark =prompt("Enter your marks",0);
 console.log(mark >50 ? `Marks are ${mark} and grade is A`:mark ==50 ? `Marks are ${mark} and grade is B`:`Marks are ${mark} and grade is c`)




